def ship_print(position):
    sp = " " * position
    print(sp + " x ")


while True:
   ship_print()