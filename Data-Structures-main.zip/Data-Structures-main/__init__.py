from flask import Flask

"""This needs to be isolated to support blueprints and models"""
app = Flask(__name__)