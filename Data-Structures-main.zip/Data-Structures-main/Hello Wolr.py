from random import randint
while True:
    if randint(1,2) == 1:
        print("hello world ")
    else:
        print("wolrd Hello")

